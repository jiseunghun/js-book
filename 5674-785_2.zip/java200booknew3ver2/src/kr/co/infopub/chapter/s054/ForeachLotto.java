package kr.co.infopub.chapter.s054;
// for와 배열
public class ForeachLotto {
	public static void main(String[] args) {
		int[]mm={1,6,16,22,23,33};
		for (int m : mm) {
			System.out.printf(m+"\t");
		}
		System.out.println();
	}
}
