package kr.co.infopub.chapter.s081;
public class BillboardMain {
	public static void main(String[] args) {
		// Data(자료)를 가공하여 Information(정보)를 만든다.
		// Data와 Information은 상대적 개념
		// 날닭걀을 먹으려면 날닭걀이 Data이면서 Information
		// 계란 후라이를 먹으려면 닭걀은 Data, 후라이를 인포메이션, 가공방법 -불로 가열(연산, 메서드)
		// 불 -가스, 전기 등 다양

		// Data의 종류는 다양
		// 기본 데이터(Raw data) -> 가공 -> 구조적 데이터 Data(txt, csv, json, xml)-> 가공 -> 정보(Information)
		// 프로그래밍 data -> 정수, 실수, 문자열, 문자, boolean으로 구분 -> 기본데이터 묶음 -> 객체 
	}
}
