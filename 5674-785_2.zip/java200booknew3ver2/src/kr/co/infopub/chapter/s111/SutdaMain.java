package kr.co.infopub.chapter.s111;
public class SutdaMain {
	public static void main(String[] args) {
		Sutda sutda=new Sutda();
		sutda.play();
	}
}
