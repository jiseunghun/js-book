package kr.co.infopub.chapter.s031;
public enum FRUIT{
	APPLE, BANANA, MANGO     //0~2 자동 초기화
}
