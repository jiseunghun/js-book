package kr.co.infopub.chapter.s024;
// 메서드
public class Hello {
	// 메서드 선언
	public static void showHello() {
		System.out.println("**********************************************");
		System.out.println("*        이 프로그래밍은 Java200이 만들었습니다.      *");
		System.out.println("**********************************************");
	}
	//메서드 호출
	public static void main(String[] args) {
		showHello();        // '메서드 이름()'
	}
}
